file_cache_path "/tmp/chef-solo"
data_bag_path "/root/chef-repo/data_bags"
cookbook_path ["/root/chef-repo/site-cookbooks"]
